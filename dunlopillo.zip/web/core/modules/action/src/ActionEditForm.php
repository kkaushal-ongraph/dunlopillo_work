<?php

namespace Drupal\action;

/**
 * Provides a form for action edit forms.
 *
 * @internal
 */
class ActionEditForm extends ActionFormBase {

}
